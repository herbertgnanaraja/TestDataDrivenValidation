import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
 
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.lang.String;
 
public class xpathtest {
    public static void main(String[] args) {
    	
    	String ss = "<SOAP-ENV:Envelope>"
    			+   "<SOAP-ENV:Header>"
    		      +"<ns:bmoHdrRs>"
    		       +  "<ns:version>1.0</ns:version>"
    		        + "<ns:srcInfo>"
    		            +"<ns:chType>BRN</ns:chType>"
    		            +"<ns:chInst>0159</ns:chInst>"
    		+            "<ns:appName>Startup.</ns:appName>"
    		            +"<ns:hostName>D0159A01QD016</ns:hostName>"
    		+            "<ns:userId>sle59c</ns:userId>"
    		         +"</ns:srcInfo>"
    		+         "<ns:clientDt>2015-09-30T12:56:24.369</ns:clientDt>"
    		         +"<ns:startTimeStamp>2015-09-30T12:56:22.578</ns:startTimeStamp>"
    		+         "<ns:serviceInfo>"
    		            +"<ns:serviceName>OCIFInvolvedPartyService</ns:serviceName>"
    		+            "<ns:serviceFunc>CreateProspect</ns:serviceFunc>"
    		         +"</ns:serviceInfo>"
    		      +"</ns:bmoHdrRs>"
    		   +"</SOAP-ENV:Header>"
    		+   "<SOAP-ENV:Body>"
    		      +"<ns0:createProspectResponse>"
    		         +"<serviceHeader>"
    		            +"<serviceHeaderId>1</serviceHeaderId>"
    		+            "<hubTimestamp>2015-12-31T11:20:28.972-05:00</hubTimestamp>"
    		            +"<requestId>CC2013-10-21T13:42:06.178c11eb45c-2f2c-45a5-ba94-c5929d84a79e</requestId>"
    		+            "<remoteSystemTransactionStartTimestamp>2013-10-21T13:42:06.1784797-04:00</remoteSystemTransactionStartTimestamp>"
    		            +"<serviceReferenceNumber>HubInv123111cd18e458-01c5-4d22-b748-e86a7736b3a1</serviceReferenceNumber>"
    		+            "<sessionId/>"
    		            +"<channel>1</channel>"
    		+            "<sessionLanguageType>en-CA</sessionLanguageType>"
    		            +"<serviceHeaderDevice>"
    		               +"<workstationNumber>D2550A04QD009</workstationNumber>"
    		+               "<branchTransitNumber>0124</branchTransitNumber>"
    		            +"</serviceHeaderDevice>"
    		+            "<serviceHeaderPartyRoleList>"
    		               +"<serviceHeaderPartyRole>"
    		                  +"<rankNumber>1</rankNumber>"
    		+                  "<loginCredentialId>SLE52A</loginCredentialId>"
    		                  +"<multiFactorAuthenticationIndicator>0</multiFactorAuthenticationIndicator>"
    		+                  "<involvedPartyType>Individual</involvedPartyType>"
    		                  +"<involvedPartyRoleType>Employee</involvedPartyRoleType>"
    		+                  "<credentialType>ActiveDirectoryId</credentialType>"
    		               +"</serviceHeaderPartyRole>"
    		            +"</serviceHeaderPartyRoleList>"
    		+            "<originatorAppCatId>112</originatorAppCatId>"
    		         +"</serviceHeader>"
    		+         "<createProspectResponseBody>"
    		            +"<createProspectResponse>"
    		               +"<p308:CreateProspectOutputHeader>"
    		                  +"<p248:status>"
    		                     +"<p248:Severity>I</p248:Severity>"
    		+                     "<p248:Code>0000</p248:Code>"
    		                  +"</p248:status>"
    		+                  "<p248:transactionReference>MR0736511202684S</p248:transactionReference>"
    		               +"</p308:CreateProspectOutputHeader>"
    		+               "<p308:CreateProspectOutputBody>"
    		                  +"<p602:UpdatedInvolvedParty>"
    		                     +"<p602:ObjectIdentifier>020365408303600</p602:ObjectIdentifier>"
    		                  +"</p602:UpdatedInvolvedParty>"
    		               +"</p308:CreateProspectOutputBody>"
    		+               "<ns1:partyIdReferences>"
    		                  +"<ECIFId>1234</ECIFId>"
    		+                  "<OCIFId>020365408303600</OCIFId>"
    		               +"</ns1:partyIdReferences>"
    		            +"</createProspectResponse>"
    		         +"</createProspectResponseBody>"
    		      +"</ns0:createProspectResponse>"
    		   +"</SOAP-ENV:Body>"
    		+"</SOAP-ENV:Envelope>";
 
        try {
            FileInputStream file = new FileInputStream(new File("C:/test/Xpath/CrPros.xml"));
                 
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
             
            DocumentBuilder builder =  builderFactory.newDocumentBuilder();
             
            InputStream stream = new ByteArrayInputStream(ss.getBytes(StandardCharsets.UTF_8));
            Document xmlDocument = builder.parse(file);
 
            XPath xPath =  XPathFactory.newInstance().newXPath();
 
            System.out.println("*************************");
            String realfield = "ECIFId";
            String expression = "//*/" + realfield + "[2]";
            //System.out.println(expression);
            String email = xPath.compile(expression).evaluate(xmlDocument).trim();
            System.out.println(email);
			
			 } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }
        
        String t = "ECIFId[index]";
        
        int a = t.indexOf("[index]");
        
            
        System.out.println(t.replace("[index]", "[1]"));
        
        		
    }
}