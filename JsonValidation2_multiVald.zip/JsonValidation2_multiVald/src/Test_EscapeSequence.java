import java.io.*;
import org.apache.commons.lang.StringEscapeUtils;

public class Test_EscapeSequence {

	public static void main(String[] args) {
		
		String ss;
		
		
		try {
			CompareXML c = new CompareXML();
			
			String docMetadata = "\"docMetadata\"";
			
			
			  FileReader fileReader = 
		                new FileReader("C:/test/Json_object3.txt");

		            // Always wrap FileReader in BufferedReader.
		            BufferedReader bufferedReader = new BufferedReader(fileReader);
			
		            StringBuilder sb = new StringBuilder();
		            String line = bufferedReader.readLine();

		            while (line != null) {
		            	
		            	if (line.indexOf(docMetadata) != -1)
						{
	
		            		 System.out.println("Found the line");
		            		
		            		 String EStarget = line.substring(docMetadata.length() + 7, line.length()-1);
		            		System.out.println(EStarget);
		            		System.out.println(StringEscapeUtils.escapeJava(EStarget));
		            		 sb.append(line);
		            		
						}
		            	else
		            	   sb.append(line);
		            	
		            	
		                sb.append("\n");
		                line = bufferedReader.readLine();
		            }
		            ss=sb.toString();
		            
		            		
		            bufferedReader.close();
	
		            
		            System.out.println(ss);		
		            		 		
		            System.out.println("==================================");
		            
		            
		            //int index = ss.indexOf("docMetadata");          
		            //System.out.println("Index = " + index);
		           //System.out.println(ss.substring(index));	
		            
		            
		            
		            
		            
		            
		            String ES = StringEscapeUtils.escapeJava(ss);
		            
		            System.out.println("==================================");
		            
		            
		            System.out.println(ES);		
		            		
			//c.JsonToXml(ss);
		      //     c.LoadSheet("C:/test/Compare/DriverSheet.xlsx", "Sheet3",0);
		        //    String s=c.assertJSON(ss, "TC_006", 0);
		        //    System.out.println(s);
			
		
		} catch (Exception e) {
			System.out.println("\nError!!! " + e);
		}
	}
}
