
public class Test2 {
	
	public static void main(String[] args) {
		
/*//		try {
//		CompareXML c = new CompareXML();
//		
//		System.out.println(c.LoadSheet("C:/test/Compare/DriverSheet.xlsx", "Sheet3",2));
//		}
//		catch (Exception e) {
//			System.out.println("\nError!!! " + e);
		}*/
		
		String s = "SUCCESS#PARTIAL";
		
		String [] splitStr = s.split("#");
		
		for(int z = 0; z<splitStr.length;z++)
		{
			System.out.println("\n" + splitStr[z] + "  " + z);
		}
		
	}

}
