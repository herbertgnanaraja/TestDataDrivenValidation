package com.functions;

import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFSheet;

public class Xfields{
	
	public static XSSFSheet[] spreadsheet = new XSSFSheet[3];
	public static ArrayList<ArrayList <String>> titleList = new ArrayList<ArrayList<String>>();
	public static int[] titleList_count = new int[3];
	public static int[] rowCount = new int[3];
	}
