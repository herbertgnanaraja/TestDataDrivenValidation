package com.functions;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import java.util.ArrayList;

import java.util.Date;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;


import org.apache.log4j.Logger;
import java.io.*;
import java.sql.SQLException;


// Json to Xml conversion library
import org.json.JSONObject;
import org.json.XML;

public class CompareXML {
	
	public static Logger logd;
	
	
	CompareXML(){
	logd = Logger.getLogger(CompareXML.class.getName());	
	
	}
	
	String loggerload() {
		String status;
		
		status = "test";
		return status;
	}
	
	
	//Logging function
	void logtest(String logMessage){
		String logstring = dateTime() + " " +logMessage;
		
		logd.info(logstring);
	}
	
	
	
	//Convert cell values to string and send
	public String getCellValue(Cell cell)	{
		String temp = null;
		
		switch(cell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			temp = Boolean.toString(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_NUMERIC:
			temp = Double.toString(cell.getNumericCellValue());
			temp = new DecimalFormat("0.####").format(Double.parseDouble(temp));
			break;
		case Cell.CELL_TYPE_STRING:
			temp = cell.getStringCellValue().toString();
			break;
		}
		return temp;
	}
	
	//Load spread sheet and tab
	public String LoadSheet(String filename, String tab, int SheetNumber) throws Exception
	{
		
		FileInputStream fis = new FileInputStream(new File(filename));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet spreadsheet=workbook.getSheet(tab);
		
		int rowCount = spreadsheet.getPhysicalNumberOfRows();
		
		fis.close();
		
		//Load Title--------------------------------------------
		
		Cell cell = null;
		
		ArrayList<String> titleList = new ArrayList<String>();
		int column = 0;
	
		do
		{
			cell = spreadsheet.getRow(0).getCell(column); //get column reference
		
			if (cell != null) //if column is created already
			{
				String c = getCellValue(cell);
				if(c != "")
					titleList.add(c);
				column++;
			}
		}while(cell !=null);
		
		int titleList_count = column-1;
		Xfields.spreadsheet[SheetNumber] =null;
		Xfields.spreadsheet[SheetNumber] = spreadsheet;
		Xfields.rowCount[SheetNumber] = rowCount;
		//Xfields.titleList.add(titleList);
		Xfields.titleList.add(SheetNumber, titleList);
		Xfields.titleList_count[SheetNumber] = titleList_count;
		
		workbook.close();
		return "Loaded";
		
	}
	
	
	//Retrieve xml field value from XML using xpath
	public String getXMLfieldValue(InputStream stream, String field, int index)
	{
		String fieldValue=new String();
		
		try {
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder =  builderFactory.newDocumentBuilder();
		
		Document xmlDocument = builder.parse(stream);
		
		XPath xPath =  XPathFactory.newInstance().newXPath();
		
		
		String repIndex = "[" + Integer.toString(index)+ "]";
		
		String tempField = field.replace("[index]",repIndex);
		//tempField = tempField.replace("/","/*:");
		
		String expression = "//" + tempField;
		System.out.println("expression from system print: " + expression);
		logtest("expression: " + expression);
		fieldValue = xPath.compile(expression).evaluate(xmlDocument).trim();
			
		 builder.reset();
		 } catch (FileNotFoundException e) {
	            e.printStackTrace();
	            logtest(e.toString());
	        } catch (SAXException e) {
	            e.printStackTrace();
	            logtest(e.toString());
	        } catch (IOException e) {
	            e.printStackTrace();
	            logtest(e.toString());
	        } catch (ParserConfigurationException e) {
	            e.printStackTrace();
	            logtest(e.toString());
	        } catch (XPathExpressionException e) {
	            e.printStackTrace();
	            logtest(e.toString());
	        }       
			
			return fieldValue;
			
	}
	
	//Main function to be called for assertion
	public String assertXML(String XMLdata, String testCaseID, int SheetNumber)
	{
		String result = new String();
		String assertFlag = "True";
		boolean rowFound = false;
		int tcOcc =0;
		Cell cell = null;
		
		
		for (int i = 1; i < Xfields.rowCount[SheetNumber]; i++)
		{
			cell = Xfields.spreadsheet[SheetNumber].getRow(i).getCell(0);
			if (testCaseID.compareTo(getCellValue(cell)) == 0) // To find the testCaseID row
			{
				tcOcc++;
				rowFound = true;
				System.out.println("assertXML Row" + i);
				logtest("assertXML Row" + i);
				
				assertFlag = assertRow(XMLdata,i,tcOcc,SheetNumber);
				if(assertFlag.compareTo("true") !=0 )
				{
					result = assertFlag;
					break;
				}
				else
					result = "true";			
			}
		}
		
		
		if(rowFound == false)
			return "Testcase ID not found";
		
		return result;
	}
	
	//Assert each test data row
	public String assertRow(String XMLdata, int row, int index, int SheetNumber)
	{
		boolean passFlag = true;
		String xlvalue =new String();
		String xmlvalue = new String();
		String field = new String();
		String rowResult = "true";
		Cell cell = null;
		int j = 1;
		
		while(j <= Xfields.titleList_count[SheetNumber] && passFlag == true)
		{
			field = Xfields.titleList.get(SheetNumber).get(j);
			cell = Xfields.spreadsheet[SheetNumber].getRow(row).getCell(j);
			
			if (cell != null)
			{
				//System.out.println("Cell not null");
				logtest("Cell not null");
				xlvalue = getCellValue(cell);
				
				if (xlvalue != null && xlvalue != "")
				{
					//System.out.println("Excel field not null");
					logtest("Excel field not null");
				InputStream stream = new ByteArrayInputStream(XMLdata.getBytes());
			
				xmlvalue = getXMLfieldValue(stream,field,index);
			
				//System.out.println("Field: " +field+", Spreadsheet value: "+xlvalue+", Actual value: "+xmlvalue+", Index: "+index);
				logtest("Field: " +field+", Spreadsheet value: "+xlvalue+", Actual value: "+xmlvalue+", Index: "+index);

				if(xlvalue.compareTo("*") ==0 && xmlvalue != "") //Verification for any value
				{
					passFlag = true;
					rowResult = "true";
				}
				else if(xlvalue.compareTo("!!") ==0)	//Verification for no field or element
				{
					if(xmlvalue == "")
					{
						passFlag = true;
						rowResult = "true";
					}
					else
					{
						//System.out.println(xmlvalue.indexOf(xlvalue));
						logtest("In No field else block");
						passFlag = false;
						rowResult = "Looks like the field \""+ field + "\" appears in XML/JSON doc";
					}
				}
				else if(xlvalue.indexOf("**") == 0)	//Verification for contains
				{
					//System.out.println("Inside **");
					logtest("Inside **");
					xlvalue = xlvalue.replace("**", "");
					//System.out.println("After stripping (**): " + xlvalue);
					logtest("After stripping (**): " + xlvalue);
					if(xmlvalue.indexOf(xlvalue) != -1 && xmlvalue != "")
					{
						System.out.println(xmlvalue.indexOf(xlvalue));
						passFlag = true;
						rowResult = "true";
					}
					else
					{
						System.out.println(xmlvalue.indexOf(xlvalue));
						passFlag = false;
						rowResult = "Field: " + field + ", Spreadsheet value: " + xlvalue + ", Actual Value: " +  xmlvalue;
					}
				}
				else if(xlvalue.indexOf("*!") == 0)	//Verification for not contains or not equal to
				{
					//System.out.println("Inside *!");
					logtest("Inside *!");
					xlvalue = xlvalue.replace("*!", "");
					//System.out.println("After stripping (*!): " + xlvalue);
					logtest("After stripping (*!): " + xlvalue);
					if(xmlvalue.indexOf(xlvalue) == -1)
					{
						System.out.println(xmlvalue.indexOf(xlvalue));
						passFlag = true;
						rowResult = "true";
					}
					else
					{
						System.out.println(xmlvalue.indexOf(xlvalue));
						passFlag = false;
						rowResult = "Field: " + field + ", Spreadsheet value: [Not equal to] " + xlvalue + ", Actual Value: " +  xmlvalue;
					}
				}
				else if(xlvalue.indexOf("*@") == 0)	//Verification for Case insensitive equal to
				{
					//System.out.println("Inside *@");
					logtest("Inside *@");
					xlvalue = xlvalue.replace("*@", "");
					//System.out.println("After stripping (*@): " + xlvalue);
					logtest("After stripping (*@): " + xlvalue);
					String temp_xmlvalue = xmlvalue.toLowerCase();
					String temp_xlvalue = xlvalue.toLowerCase();
					
					if(temp_xmlvalue.compareTo(temp_xlvalue) == 0)
					{
						passFlag = true;
						rowResult = "true";
					}
					else
					{
						passFlag = false;
						rowResult = "Field: " + field + ", Spreadsheet value: " + xlvalue + ", Actual Value: " +  xmlvalue;
					}
				}
				else if(xlvalue.indexOf("*$") == 0)	//Verification for Case insensitive contains
				{
					//System.out.println("Inside *$");
					logtest("Inside *$");
					xlvalue = xlvalue.replace("*$", "");
					//System.out.println("After stripping (*$): " + xlvalue);
					logtest("After stripping (*$): " + xlvalue);
					
					String temp_xmlvalue = xmlvalue.toLowerCase();
					String temp_xlvalue = xlvalue.toLowerCase();
					
					if(temp_xmlvalue.indexOf(temp_xlvalue) != -1 && xmlvalue != "")
					{
						System.out.println(temp_xmlvalue.indexOf(temp_xlvalue));
						passFlag = true;
						rowResult = "true";
					}
					else
					{
						System.out.println(temp_xmlvalue.indexOf(temp_xlvalue));
						passFlag = false;
						rowResult = "Field: " + field + ", Spreadsheet value: " + xlvalue + ", Actual Value: " +  xmlvalue;
					}
				}
				else if(xlvalue.indexOf("||") != -1)	//Verification for matching any one of multiple values e.g. text1||text2||text3
				{
					//System.out.println("Inside ||");
					logtest("Inside ||");
									
					String [] splitStr = xlvalue.split("||");
					
					int Siter = 0;
					boolean fflag = false;
					
					while(Siter < splitStr.length && fflag == false)
					{
						if(splitStr[Siter].toLowerCase().compareTo(xmlvalue.toLowerCase()) == 0)
						{	
							fflag = true;
						}
						Siter++;
					}
					
					if(fflag == true)
					{	
							//System.out.println("Matching value:" + splitStr[Siter-1]);
							logtest("Matching value:" + splitStr[Siter-1]);
							passFlag = true;
							rowResult = "true";
							
					}										
					else
					{
						passFlag = false;
						rowResult = "Field: " + field + ", Spreadsheet value: " + xlvalue + ", Actual Value: " +  xmlvalue;
					}
				}
				
				//---------------------------------------------------------------------
				else if(xlvalue.compareTo(xmlvalue)==0)	//Verification for match
				{
					passFlag = true;
					rowResult = "true";
				}
				else
				{
					passFlag = false;
					rowResult = "Field: " + field + ", Spreadsheet value: " + xlvalue + ", Actual Value: " +  xmlvalue;
				}
				
				}
							
			}
			j++;
			
		}
		
		return rowResult;
	}
	
	//To write something in the excel
	public void writeSheet(String filename, String tab, String text, int row, int col) throws Exception
	{
		XSSFWorkbook workbook;
		XSSFSheet spreadsheet;
		
		File Ofile = new File(filename);
		
		if (Ofile.exists())
		{		
			FileInputStream fis = new FileInputStream(Ofile);
			workbook = new XSSFWorkbook(fis);
			spreadsheet = workbook.getSheet(tab);
			fis.close();
		}
		else
		{
			workbook = new XSSFWorkbook();
			spreadsheet = workbook.createSheet(tab);
		}
		
		Cell cell = null;
		XSSFRow Srow;
		
		Srow = spreadsheet.getRow(row);	//Get row reference
		if(Srow == null)	//if row is not created already
			Srow = spreadsheet.createRow(row);	//Create a new row
				
		cell = spreadsheet.getRow(row).getCell(col); //get column reference
		
		if (cell == null) //if column is created already
			cell = Srow.createCell(col);	//Create a new column
		
		cell.setCellValue((String)text);	//Write text into string
		
		
		
		FileOutputStream outFile =new FileOutputStream(new File(filename));
		workbook.write(outFile);
		outFile.close();
	}
	
	public String dateTime()
	{
		String result;
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
		Date date = new Date();
		result = dateFormat.format(date); 
				
		return result;
	}
	
	//Append tabulated string to each cell at end of row
	public void AppendExcel(String filename, String tab, String text) throws Exception
	{
		XSSFWorkbook workbook;
		XSSFSheet spreadsheet;
		
		File Ofile = new File(filename);
		
		if (Ofile.exists())
		{		
			FileInputStream fis = new FileInputStream(Ofile);
			workbook = new XSSFWorkbook(fis);
			spreadsheet = workbook.getSheet(tab);
			fis.close();
		}
		else
		{
			workbook = new XSSFWorkbook();
			spreadsheet = workbook.createSheet(tab);
		}
		
		Cell cell = null;
		XSSFRow Srow;
		
		int LastRowNum = spreadsheet.getLastRowNum();
				
		//System.out.println("Last row number: " + LastRowNum);
		logtest("Last row number: " + LastRowNum);
		
		String [] splitStr = text.split("\t");
		
		Srow = spreadsheet.getRow(LastRowNum+1);	//Get row reference
		if(Srow == null)	//if row is not created already
			Srow = spreadsheet.createRow(LastRowNum+1);	//Create a new row
		
		for(int Siter=0;Siter<splitStr.length;Siter++)
		{
			//System.out.println("Split string: " + splitStr[Siter]);
			logtest("Split string: " + splitStr[Siter]);
			
							
			cell = spreadsheet.getRow(LastRowNum+1).getCell(Siter); //get column reference
		
			if (cell == null) //if column is created already
				cell = Srow.createCell(Siter);	//Create a new column
		
			cell.setCellValue((String)splitStr[Siter]);	//Write text into string
		
		}
		
		FileOutputStream outFile =new FileOutputStream(new File(filename));
		workbook.write(outFile);
		outFile.close();
	}
	
	public String assertJSON(String JsonData, String testCaseID, int SheetNumber)
	{
		String final_xml;
		String result = new String();
		
		try{
		
		JSONObject jsonObj = new JSONObject(JsonData);
		final_xml = "<responsexml>" + XML.toString(jsonObj) + "</responsexml>";
	    //System.out.println("JsonToXML:" + final_xml);
	    logtest("JsonToXML:" + final_xml);
	    
	    result = assertXML(final_xml, testCaseID, SheetNumber);
	    logtest(result);
	   		
		} catch (Exception e) {
			System.out.println("\nError!!! " + e);
			logtest(e.toString());
		}
		
		return result;
		
	}
	
}