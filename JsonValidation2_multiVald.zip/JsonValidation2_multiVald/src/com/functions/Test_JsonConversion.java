package com.functions;

import java.io.*;

public class Test_JsonConversion {

	public static void main(String[] args) {
		
		String ss;
		
		
		try {
			CompareXML c = new CompareXML();
			
			
			  FileReader fileReader = 
		                new FileReader("C:/test/Json_object4.txt");

		            // Always wrap FileReader in BufferedReader.
		            BufferedReader bufferedReader = new BufferedReader(fileReader);
			
		            StringBuilder sb = new StringBuilder();
		            String line = bufferedReader.readLine();

		            while (line != null) {
		                sb.append(line);
		                sb.append("\n");
		                line = bufferedReader.readLine();
		            }
		            ss=sb.toString();
		            
		            		
		            bufferedReader.close();
	
		            
		            System.out.println(ss);		
		            		 		
		            System.out.println("==================================");	
		            		
		            		
			//c.JsonToXml(ss);
		           c.LoadSheet("C:/test/Compare/DriverSheet.xlsx", "Sheet3",0);
		            String s=c.assertJSON(ss, "TC_007", 0);
		            System.out.println("Output from fucntion: " + s);
			
		
		} catch (Exception e) {
			System.out.println("\nError!!! " + e);
		}
	}
}
