import java.util.*;

public class SampleList {

	public static void main(String[] args) {
		
		ArrayList<ArrayList<String>> table = new ArrayList<ArrayList<String>>();
		ArrayList <String> titleList = new ArrayList<String>();
		int[] rowCount = new int[3];
		
		rowCount[0] = 4;
		
		System.out.println(rowCount[0]);

	}

}
