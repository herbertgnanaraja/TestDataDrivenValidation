

public class Test {

	public static void main(String[] args) {
		
		String ss = "<SOAP-ENV:Envelope>"
    			+   "<SOAP-ENV:Header>"
    		      +"<ns:bmoHdrRs>"
    		       +  "<ns:version>1.0</ns:version>"
    		        + "<ns:srcInfo>"
    		            +"<ns:chType>BRN</ns:chType>"
    		            +"<ns:chInst>0159</ns:chInst>"
    		+            "<ns:appName>Startup.</ns:appName>"
    		            +"<ns:hostName>D0159A01QD016</ns:hostName>"
    		+            "<ns:userId>sle59c</ns:userId>"
    		         +"</ns:srcInfo>"
    		+         "<ns:clientDt>2015-09-30T12:56:24.369</ns:clientDt>"
    		         +"<ns:startTimeStamp>2015-09-30T12:56:22.578</ns:startTimeStamp>"
    		+         "<ns:serviceInfo>"
    		            +"<ns:serviceName>OCIFInvolvedPartyService</ns:serviceName>"
    		+            "<ns:serviceFunc>CreateProspect</ns:serviceFunc>"
    		         +"</ns:serviceInfo>"
    		      +"</ns:bmoHdrRs>"
    		   +"</SOAP-ENV:Header>"
    		+   "<SOAP-ENV:Body>"
    		      +"<ns0:createProspectResponse>"
    		         +"<serviceHeader>"
    		            +"<serviceHeaderId>1</serviceHeaderId>"
    		+            "<hubTimestamp>2015-12-31T11:20:28.972-05:00</hubTimestamp>"
    		            +"<requestId>CC2013-10-21T13:42:06.178c11eb45c-2f2c-45a5-ba94-c5929d84a79e</requestId>"
    		+            "<remoteSystemTransactionStartTimestamp>2013-10-21T13:42:06.1784797-04:00</remoteSystemTransactionStartTimestamp>"
    		            +"<serviceReferenceNumber>HubInv123111cd18e458-01c5-4d22-b748-e86a7736b3a1</serviceReferenceNumber>"
    		+            "<sessionId/>"
    		            +"<channel>1</channel>"
    		+            "<sessionLanguageType>en-CA</sessionLanguageType>"
    		            +"<serviceHeaderDevice>"
    		               +"<workstationNumber>D2550A04QD009</workstationNumber>"
    		+               "<branchTransitNumber>0124</branchTransitNumber>"
    		            +"</serviceHeaderDevice>"
    		+            "<serviceHeaderPartyRoleList>"
    		               +"<serviceHeaderPartyRole>"
    		                  +"<rankNumber>1</rankNumber>"
    		+                  "<loginCredentialId>SLE52A</loginCredentialId>"
    		                  +"<multiFactorAuthenticationIndicator>0</multiFactorAuthenticationIndicator>"
    		+                  "<involvedPartyType>Individual1</involvedPartyType>"
    		+                  "<involvedPartyType>Individual2</involvedPartyType>"
    		+                  "<involvedPartyType>Individual3</involvedPartyType>"
    		                  +"<involvedPartyRoleType>Employee</involvedPartyRoleType>"
    		+                  "<credentialType>ActiveDirectoryId</credentialType>"
    		               +"</serviceHeaderPartyRole>"
    		            +"</serviceHeaderPartyRoleList>"
    		+            "<originatorAppCatId>112</originatorAppCatId>"
    		         +"</serviceHeader>"
    		+         "<createProspectResponseBody>"
    		            +"<createProspectResponse>"
    		               +"<p308:CreateProspectOutputHeader>"
    		                  +"<p248:status>"
    		                     +"<p248:Severity>I</p248:Severity>"
    		+                     "<p248:Code>0000</p248:Code>"
    		                  +"</p248:status>"
    		+                  "<p248:transactionReference>MR0736511202684S</p248:transactionReference>"
    		               +"</p308:CreateProspectOutputHeader>"
    		+               "<p308:CreateProspectOutputBody>"
    		                  +"<p602:UpdatedInvolvedParty>"
    		                     +"<p602:ObjectIdentifier>020365408303600</p602:ObjectIdentifier>"
    		                  +"</p602:UpdatedInvolvedParty>"
    		               +"</p308:CreateProspectOutputBody>"
    		+               "<ns1:partyIdReferences>"    		                 
    		                  +"<ECIFId>ECIF1</ECIFId>"
    		+                  "<OCIFId>020365408303600</OCIFId>"
    		               +"</ns1:partyIdReferences>"
    		               +"<ns1:partyIdReferences>"    		                 
 		                  +"<ECIFId>ECIF2</ECIFId>"
 		+                  "<OCIFId>020365408303600</OCIFId>"
 		               +"</ns1:partyIdReferences>"
   		    		+"<ns1:partyIdReferences>"    		                 
	                  +"<ECIFId>ECIF3</ECIFId>"
	+                  "<OCIFId>020365408303600</OCIFId>"
	               +"</ns1:partyIdReferences>"
    		            +"</createProspectResponse>"
    		         +"</createProspectResponseBody>"
    		      +"</ns0:createProspectResponse>"
    		   +"</SOAP-ENV:Body>"
    		+"</SOAP-ENV:Envelope>";
		
		try {
			CompareXML c = new CompareXML();
			
			String a = c.LoadSheet("C:/test/Compare/DriverSheet.xlsx", "Sheet3",0);
	
			//c.LoadTitle();
			
			
//			System.out.println("------------------------------");
//			System.out.println(CompareXML.titleList_count);
//			for(String temp : CompareXML.titleList)
//			{
//				System.out.println(temp);
//			}
//			Thread.sleep(5000);  
//			System.out.println("Sta	rting------------------------------");
//			
//			for(int i=1;i<CompareXML.titleList_count;i++)
//				System.out.println(CompareXML.titleList.get(i));
			
			//InputStream stream = new ByteArrayInputStream(ss.getBytes(StandardCharsets.UTF_8));
			//String a = c.getXMLfieldValue(stream, "partyIdReferences[index]/ECIFId", 2);
			//System.out.println("XML field Value: " + a);
			
			
			CompareXML d = new CompareXML();
			System.out.println("RESULT: "+ d.assertXML(ss, "TC_002",0));			
			
					
			
		
		} catch (Exception e) {
			System.out.println("\nError!!! " + e);
		}
	}
}
