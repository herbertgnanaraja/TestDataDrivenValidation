
public class Test_Excel {
	

	public static void main(String[] args) {
		
		writeExcel we = new writeExcel();
		try {
			we.AppendExcel("C:/test/exwr1.xlsx", "Check", "Hello2	after tab3	next one of4	with\nret\nurn");
			System.out.println("File written");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println(we.dateTime());

	}
}
