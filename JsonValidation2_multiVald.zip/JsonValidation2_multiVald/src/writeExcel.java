import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.hssf.util.HSSFColor;

public class writeExcel {
	
	public void writeSheet(String filename, String tab, String text, int row, int col) throws Exception
	{
		XSSFWorkbook workbook;
		XSSFSheet spreadsheet;
		
		File Ofile = new File(filename);
		
		if (Ofile.exists())
		{		
			FileInputStream fis = new FileInputStream(Ofile);
			workbook = new XSSFWorkbook(fis);
			spreadsheet = workbook.getSheet(tab);
			fis.close();
		}
		else
		{
			workbook = new XSSFWorkbook();
			spreadsheet = workbook.createSheet(tab);
		}
		
		Cell cell = null;
		XSSFRow Srow;
		
		Srow = spreadsheet.getRow(row);	//Get row reference
		if(Srow == null)	//if row is not created already
			Srow = spreadsheet.createRow(row);	//Create a new row
				
		cell = spreadsheet.getRow(row).getCell(col); //get column reference
		
		if (cell == null) //if column is created already
			cell = Srow.createCell(col);	//Create a new column
		
		cell.setCellValue((String)text);	//Write text into string
		
		
		
		FileOutputStream outFile =new FileOutputStream(new File(filename));
		workbook.write(outFile);
		outFile.close();
	}
	
	public void AppendExcel(String filename, String tab, String text) throws Exception
	{
		XSSFWorkbook workbook;
		XSSFSheet spreadsheet;
		
		File Ofile = new File(filename);
		
		if (Ofile.exists())
		{		
			FileInputStream fis = new FileInputStream(Ofile);
			workbook = new XSSFWorkbook(fis);
			spreadsheet = workbook.getSheet(tab);
			fis.close();
		}
		else
		{
			workbook = new XSSFWorkbook();
			spreadsheet = workbook.createSheet(tab);
		}
		
		Cell cell = null;
		XSSFRow Srow;
		
		int LastRowNum = spreadsheet.getLastRowNum();
				
		System.out.println("Last row number: " + LastRowNum);
		
		String [] splitStr = text.split("\t");
		
		Srow = spreadsheet.getRow(LastRowNum+1);	//Get row reference
		if(Srow == null)	//if row is not created already
			Srow = spreadsheet.createRow(LastRowNum+1);	//Create a new row
		
		for(int Siter=0;Siter<splitStr.length;Siter++)
		{
			System.out.println("Split string: " + splitStr[Siter]);
			
							
			cell = spreadsheet.getRow(LastRowNum+1).getCell(Siter); //get column reference
		
			if (cell == null) //if column is created already
				cell = Srow.createCell(Siter);	//Create a new column
		
			cell.setCellValue((String)splitStr[Siter]);	//Write text into string
		
		}
		
		FileOutputStream outFile =new FileOutputStream(new File(filename));
		workbook.write(outFile);
		outFile.close();
	}
	
	public String dateTime()
	{
		String result;
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd-HH-mm-ss");
		Date date = new Date();
		result = dateFormat.format(date); 
				
		return result;
	}
	
}
